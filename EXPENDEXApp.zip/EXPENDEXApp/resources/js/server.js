
require('dotenv').config();

const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// MySQL Database Connection Pool
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'expendex_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Check required environment variables
if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is missing from your .env file.');
}

// Generate JWT Token
const generateToken = (userId) => {
    return jwt.sign(
        { id: userId },
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
    );
};

// Test endpoint
app.get('/api/db-test', async (req, res) => {
    try {
        const [rows] = await pool.query(
            'SELECT DATABASE() AS database_name'
        );

        res.json({
            success: true,
            message: 'Database connected successfully!',
            database: rows[0].database_name
        });
    } catch (err) {
        console.error('Database error:', err.message);
        res.status(500).json({
            error: 'Database connection failed.'
        });
    }
});

// ==========================================
// REGISTER ENDPOINT
// ==========================================
app.post('/api/auth/register', async (req, res) => {
    const { full_name, email, password } = req.body;

    if (
        typeof full_name !== 'string' ||
        typeof email !== 'string' ||
        typeof password !== 'string' ||
        !full_name.trim() ||
        !email.trim() ||
        !password
    ) {
        return res.status(400).json({
            error: 'All fields are required.'
        });
    }

    const cleanName = full_name.trim();
    const cleanEmail = email.trim().toLowerCase();

    if (cleanName.length > 100) {
        return res.status(400).json({
            error: 'Full name must not exceed 100 characters.'
        });
    }

    if (cleanEmail.length > 255 ||
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        return res.status(400).json({
            error: 'Invalid email format.'
        });
    }

    if (password.length < 6) {
        return res.status(400).json({
            error: 'Password must be at least 6 characters long.'
        });
    }

    try {
        const [existingUsers] = await pool.query(
            'SELECT id FROM users WHERE email = ?',
            [cleanEmail]
        );

        if (existingUsers.length > 0) {
            return res.status(409).json({
                error: 'Email is already registered.'
            });
        }

        const passwordHash = await bcrypt.hash(password, 10);

        await pool.query(
            `INSERT INTO users
             (full_name, email, password_hash)
             VALUES (?, ?, ?)`,
            [cleanName, cleanEmail, passwordHash]
        );

        return res.status(201).json({
            message: 'User registered successfully.'
        });
    } catch (err) {
        console.error('Registration error:', err.message);

        if (err.code === 'ER_DUP_ENTRY') {
            return res.status(409).json({
                error: 'Email is already registered.'
            });
        }

        return res.status(500).json({
            error: 'Server error during registration.'
        });
    }
});

// ==========================================
// LOGIN ENDPOINT
// ==========================================
app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;

    if (
        typeof email !== 'string' ||
        typeof password !== 'string' ||
        !email.trim() ||
        !password
    ) {
        return res.status(400).json({
            error: 'Email and password are required.'
        });
    }

    try {
        const cleanEmail = email.trim().toLowerCase();

        const [users] = await pool.query(
            `SELECT id, full_name, email, password_hash
             FROM users
             WHERE email = ?`,
            [cleanEmail]
        );

        if (users.length === 0) {
            return res.status(401).json({
                error: 'Invalid email or password.'
            });
        }

        const user = users[0];

        const isMatch = await bcrypt.compare(
            password,
            user.password_hash
        );

        if (!isMatch) {
            return res.status(401).json({
                error: 'Invalid email or password.'
            });
        }

        const token = generateToken(user.id);

        return res.status(200).json({
            message: 'Login successful.',
            token,
            user: {
                id: user.id,
                full_name: user.full_name,
                email: user.email
            }
        });
    } catch (err) {
        console.error('Login error:', err.message);

        return res.status(500).json({
            error: 'Server error during login.'
        });
    }
});

// ==========================================
// START SERVER
// ==========================================
const PORT = Number(process.env.PORT || 5000);

async function startServer() {
    try {
        await pool.query('SELECT 1');

        console.log('MySQL database connected successfully.');

        app.listen(PORT, () => {
            console.log(
                `EXPENDEX Backend running on http://localhost:${PORT}`
            );
        });
    } catch (err) {
        console.error('Unable to connect to MySQL:', err.message);
        process.exit(1);
    }
}

startServer();
